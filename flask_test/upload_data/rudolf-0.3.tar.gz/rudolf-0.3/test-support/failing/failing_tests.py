def erroring_test():
    raise Exception()

def failing_test():
    assert False

