>>> print "The quick brown fox jumps over the lazy dog."
...     # doctest: +REPORT_NDIFF
'The quick brown zox jumps over the spam lazy dog.'

