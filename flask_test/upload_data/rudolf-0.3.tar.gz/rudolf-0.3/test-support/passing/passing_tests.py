def passing_test_1():
    pass

def passing_test_2():
    pass

